using GestionAppro.Models;

namespace GestionAppro.Data
{
    public static class FakeDb
    {
        public static List<Fournisseur> Fournisseurs { get; } = new()
        {
            new Fournisseur { Id = 1, Nom = "Fournisseur A" },
            new Fournisseur { Id = 2, Nom = "Fournisseur B" },
            new Fournisseur { Id = 3, Nom = "Fournisseur C" }
        };

        public static List<Article> Articles { get; } = new()
        {
            new Article { Id = 1, Libelle = "Article 1", PrixRef = 1000 },
            new Article { Id = 2, Libelle = "Article 2", PrixRef = 2000 },
            new Article { Id = 3, Libelle = "Article 3", PrixRef = 3000 }
        };

        public static List<Approvisionnement> Approvisionnements { get; } = new();
    }
}
