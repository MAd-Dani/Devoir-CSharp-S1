using Microsoft.AspNetCore.Mvc;
using GestionAppro.Data;
using GestionAppro.Models;

namespace GestionAppro.Controllers
{
    public class ApprovisionnementController : Controller
    {
        public IActionResult Index()
        {
            var list = FakeDb.Approvisionnements;
            return View(list);
        }

        public IActionResult Create()
        {
            ViewBag.Fournisseurs = FakeDb.Fournisseurs;
            ViewBag.Articles = FakeDb.Articles;
            return View();
        }

        [HttpPost]
        public IActionResult Create(Approvisionnement appro, int[] articleId, int[] quantite, decimal[] prixU)
        {
            appro.Id = FakeDb.Approvisionnements.Count + 1;
            appro.Reference = $"APP-{DateTime.Now:yyyyMMdd-HHmm}";
            appro.Statut = "Reçu";

            for (int i = 0; i < articleId.Length; i++)
            {
                appro.Articles.Add(new ApproArticle
                {
                    ArticleId = articleId[i],
                    Quantite = quantite[i],
                    PrixUnitaire = prixU[i]
                });
            }

            FakeDb.Approvisionnements.Add(appro);

            return RedirectToAction("Index");
        }
    }
}
