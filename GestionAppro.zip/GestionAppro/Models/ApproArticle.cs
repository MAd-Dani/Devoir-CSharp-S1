namespace GestionAppro.Models
{
    public class ApproArticle
    {
        public int ArticleId { get; set; }
        public int Quantite { get; set; }
        public decimal PrixUnitaire { get; set; }

        public decimal Montant => Quantite * PrixUnitaire;
    }
}
