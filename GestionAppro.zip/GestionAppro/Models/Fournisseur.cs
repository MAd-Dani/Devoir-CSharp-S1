namespace GestionAppro.Models
{
    public class Fournisseur
    {
        public int Id { get; set; }
        public string Nom { get; set; } = string.Empty;
    }
}
