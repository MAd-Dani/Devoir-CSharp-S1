namespace GestionAppro.Models
{
    public class Article
    {
        public int Id { get; set; }
        public string Libelle { get; set; } = string.Empty;
        public decimal PrixRef { get; set; }
    }
}
