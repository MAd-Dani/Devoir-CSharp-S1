namespace GestionAppro.Models
{
    public class Approvisionnement
    {
        public int Id { get; set; }
        public string Reference { get; set; } = string.Empty;
        public DateTime DateAppro { get; set; }
        public int FournisseurId { get; set; }
        public string Statut { get; set; } = string.Empty;
        public string Observations { get; set; } = string.Empty;
        public decimal MontantTotal => Articles.Sum(a => a.Montant);

        public List<ApproArticle> Articles { get; set; } = new();
    }
}
